const {Sequelize} = require('sequelize')

const sequelize = new Sequelize('escola', 'root', 'escola', {
    host: 'localhost',
    dialect: 'mysql',
    logging: false //evitar logs no terminal
})

module.exports = sequelize;